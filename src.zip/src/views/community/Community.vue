<template>

<div>

<h2>社区</h2>

<el-button type="primary">发帖</el-button>

<el-table :data="posts">

<el-table-column prop="title" label="标题"/>

<el-table-column prop="author" label="作者"/>

<el-table-column prop="view" label="浏览"/>

</el-table>

</div>

</template>

<script setup>

import { ref } from 'vue'

const posts = ref([
{
title:"如何学习线性规划",
author:"student01",
view:120
},
{
title:"遗传算法经验分享",
author:"modeler",
view:98
}
])

</script>