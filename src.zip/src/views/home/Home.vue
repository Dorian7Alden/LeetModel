<template>

<div class="home">

<h1>数学建模在线评测系统</h1>

<el-row :gutter="20">

<el-col :span="6">
<el-card>
<h3>题库</h3>
<p>{{stat.problem}}</p>
</el-card>
</el-col>

<el-col :span="6">
<el-card>
<h3>用户</h3>
<p>{{stat.user}}</p>
</el-card>
</el-col>

<el-col :span="6">
<el-card>
<h3>比赛</h3>
<p>{{stat.contest}}</p>
</el-card>
</el-col>

<el-col :span="6">
<el-card>
<h3>帖子</h3>
<p>{{stat.post}}</p>
</el-card>
</el-col>

</el-row>

</div>

</template>

<script setup>

import { reactive } from 'vue'

const stat = reactive({
problem:320,
user:1024,
contest:12,
post:560
})

</script>

<style scoped>

.home{
padding:30px
}

</style>