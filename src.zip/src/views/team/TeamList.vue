<template>

<div>

<h2>队伍列表</h2>

<el-table :data="teams">

<el-table-column prop="name" label="队伍"/>

<el-table-column prop="leader" label="队长"/>

<el-table-column prop="member" label="人数"/>

</el-table>

</div>

</template>

<script setup>

import { ref } from 'vue'

const teams = ref([
{
name:"数模冲冲队",
leader:"student01",
member:"2/3"
}
])

</script>