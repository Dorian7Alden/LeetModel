<template>

<div class="page">

<h2>训练中心</h2>

<p>这里是数学建模训练模块</p>


</div>

</template>

<script setup>

</script>

<style scoped>

.page{
padding:20px;
}

</style>