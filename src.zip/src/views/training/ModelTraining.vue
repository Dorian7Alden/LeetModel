<template>

<div>

<h2>模型训练</h2>

<el-card
v-for="m in models"
:key="m.id"
style="margin-bottom:20px"
>

<h3>{{m.name}}</h3>

<p>{{m.desc}}</p>

</el-card>

</div>

</template>

<script setup>

import { ref } from 'vue'

const models = ref([
{
id:1,
name:"线性规划",
desc:"运筹优化基础模型"
},
{
id:2,
name:"遗传算法",
desc:"智能优化算法"
}
])

</script>