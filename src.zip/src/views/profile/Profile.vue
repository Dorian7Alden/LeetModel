<template>

<div>

<h2>个人中心</h2>

<el-card>

<p>用户名：{{user.name}}</p>

<p>学校：{{user.school}}</p>

<p>专业：{{user.major}}</p>

</el-card>

</div>

</template>

<script setup>

const user = {

name:"student01",

school:"某大学",

major:"数学"

}

</script>