<template>

<div class="layout">

  <Sidebar />

  <div class="main">

    <Topbar />

    <div class="content">

      <router-view />

    </div>

  </div>

</div>

</template>

<script setup>

import Sidebar from "../components/layout/Sidebar.vue"
import Topbar from "../components/layout/Topbar.vue"

</script>

<style scoped>

.layout{
display:flex;
height:100vh;
}

.main{
flex:1;
display:flex;
flex-direction:column;
}

.content{
flex:1;
padding:20px;
overflow:auto;
background:#f5f7fa;
}

</style>