<template>

<div class="topbar">

<div class="left">

<h3>数学建模在线评测系统</h3>

</div>

<div class="right">

<el-avatar size="small"></el-avatar>

<span class="username">student01</span>

<el-button type="text">退出</el-button>

</div>

</div>

</template>

<style scoped>

.topbar{
height:60px;
background:white;
display:flex;
justify-content:space-between;
align-items:center;
padding:0 20px;
border-bottom:1px solid #eee;
}

.right{
display:flex;
align-items:center;
gap:10px;
}

</style>