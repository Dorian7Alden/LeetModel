<template>

<div class="sidebar">

<h2 class="logo">MathOJ</h2>

<el-menu
router
default-active="/"
class="menu"
>

<el-menu-item index="/">
首页
</el-menu-item>

<el-menu-item index="/problem">
题库
</el-menu-item>

<el-menu-item index="/contest">
比赛
</el-menu-item>

<el-menu-item index="/training">
训练
</el-menu-item>

<el-menu-item index="/community">
社区
</el-menu-item>

<el-menu-item index="/team">
组队
</el-menu-item>

<el-menu-item index="/profile">
个人中心
</el-menu-item>

</el-menu>

</div>

</template>

<style scoped>

.sidebar{
width:220px;
background:#2c3e50;
color:white;
}

.logo{
text-align:center;
padding:20px;
}

.menu{
border:none;
background:#2c3e50;
}

</style>