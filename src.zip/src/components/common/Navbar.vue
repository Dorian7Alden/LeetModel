<template>

<nav class="navbar">

<div class="logo">
MathModel
</div>

<ul class="menu">

<li>
<router-link to="/">首页</router-link>
</li>

<li>
<router-link to="/training">训练</router-link>
</li>

<li>
<router-link to="/problem-bank">题库</router-link>
</li>

<li>
<router-link to="/contest">赛事</router-link>
</li>

<li>
<router-link to="/community">社区</router-link>
</li>

<li>
<router-link to="/team">组队</router-link>
</li>

<li>
<router-link to="/profile">个人中心</router-link>
</li>

</ul>

</nav>

</template>

<style>

.navbar{
display:flex;
justify-content:space-between;
align-items:center;
padding:15px 40px;
background:#2c3e50;
color:white;
}

.menu{
display:flex;
gap:20px;
list-style:none;
}

.menu a{
color:white;
text-decoration:none;
}

</style>